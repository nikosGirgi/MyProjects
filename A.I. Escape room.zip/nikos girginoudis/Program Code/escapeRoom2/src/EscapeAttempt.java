import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class EscapeAttempt {
    //This here int keeps every escape attempt under a certain number of moves.
    private static int movesUpperLimit;
    //These two integers keep track of where the exit tile is.
    private static int exitX;
    private static int exitY;
    //These three booleans help decide whether we should stop
    //trying to escape or not.
    private static boolean humanEscaped = false;
    private static boolean humanIsEaten = false;
    private static boolean thereIsNoEscape = false;
    //This int keeps track of the hashMaps that we have already tested for alternative routes.
    private static int hashMapSearchCount = 0;
    //This is our Board.
    private static BoardRoom theBoard;
    //Here we create an arraylist that will house ALL of our attempts.
    private static ArrayList<HashMap<Integer,ArrayList<Integer>>> arrayOfAttemptHashMaps = new ArrayList<HashMap<Integer,ArrayList<Integer>>>();
    //This method will initialize the exit x and y.
    private static void setExitXY(){
        for(int i = 0; i < theBoard.getTilesArray().size(); i++){
            if(theBoard.getTilesArray().get(i).getTileType().equals("exit")){
                exitX = theBoard.getTilesArray().get(i).getX();
                exitY = theBoard.getTilesArray().get(i).getY();
            }
        }
    }
    public static void humanStatus(){
        System.out.println("After " + arrayOfAttemptHashMaps.size() + " attempts, here is what happened:");
        if(humanEscaped == true){
            System.out.println("The human managed to escape the dungeon!");
        }else if(thereIsNoEscape == true){
            System.out.println("There is no escape from this dungeon!");
        }else{
            System.out.println("Something is wrong with this program's code!!!");
        }
    }
//BEGINNING OF GETTERS AND SETTERS!!!

    public static ArrayList<HashMap<Integer, ArrayList<Integer>>> getArrayOfAttemptHashMaps() {
        return arrayOfAttemptHashMaps;
    }

    public static boolean getThereIsNoEscape() {
        return thereIsNoEscape;
    }
    public static void setMovesUpperLimit(int movesUpperLimit) {
        EscapeAttempt.movesUpperLimit = movesUpperLimit;
    }
    public static int getExitX() {return exitX;}
    public static int getExitY() {
        return exitY;
    }
    public static void setHumanEscaped(boolean humanEscaped) {
        EscapeAttempt.humanEscaped = humanEscaped;
    }
    public static void setHumanIsEaten(boolean humanIsEaten) {
        EscapeAttempt.humanIsEaten = humanIsEaten;
    }
//ENDING OF GETTERS AND SETTERS!!!
//THIS METHOD MAKES THE FIRST ATTEMPT AT ESCAPING!!!
    private static void firstEscapeAttempt(){
        //First we use the method we have to set up the exit.
        setExitXY();
        //Now we are going to create the human and the monster of our
        //dungeon as well as the necessary hashMap and counter.
        Human human = new Human();
        Monster monster = new Monster();
        HashMap<Integer,ArrayList<Integer>> FirstEscapeAttemptHashMap = new HashMap<Integer,ArrayList<Integer>>();
        int moveCounter = 1;
        Monster.getMonsterAndHumanMovesLog().add("FIRST ATTEMPT STARTS HERE:");
        //Now we need to create a loop that keeps on going until the human has escaped or is eaten.
        while (humanEscaped == false && humanIsEaten == false && moveCounter < (movesUpperLimit + 1)){
            //First one to move is the human.
            human.humanIsMoving();
            //and now the monster moves.
            monster.monsterMoves(human);
            //Now we add the human move to the HashMap.
            ArrayList<Integer> move = new ArrayList<Integer>();
            move.add(human.getHumanX());
            move.add(human.getHumanY());
            move.add(monster.getMonsterX());
            move.add(monster.getMonsterY());
            FirstEscapeAttemptHashMap.put(moveCounter, move);
            moveCounter+=1;
        }
        //Once we have exited the loop, we need to reset the humanIsEaten boolean...
        humanIsEaten = false;
        //...let the user know if the attempt stopped prematurely...
        if(moveCounter >= movesUpperLimit){
            Monster.getMonsterAndHumanMovesLog().add("This attempt took more moves than allowed, so it ended prematurely");
        }
        //...and we also need to add this attempt to the list.
        arrayOfAttemptHashMaps.add(FirstEscapeAttemptHashMap);
        Monster.getMonsterAndHumanMovesLog().add("FIRST ATTEMPT ENDS.");
    }
//THIS METHOD TAKES A HASHMAP AND A NUMBER FOR HOW MANY MOVES WE NEED TO GO BACKWARDS AND RETURNS A NEW HASHMAP!!!
    private static HashMap<Integer,ArrayList<Integer>> backtrackingTheHashMap(HashMap<Integer,ArrayList<Integer>> argumentHashMap, int backtracking){
        //Let's remove the moves we don't need.
        HashMap<Integer,ArrayList<Integer>> returnHashMap = new HashMap<Integer,ArrayList<Integer>>();
        for(int i = 1; i <= argumentHashMap.size() - backtracking; i++){
            returnHashMap.put(i,argumentHashMap.get(i));
        }
        return returnHashMap;
    }
//THIS METHOD TAKES TWO HASHMAPS AND COMPARES THEM TO SEE IF THEY ARE THE SAME!!!
    private static boolean comparingHashMaps(HashMap<Integer,ArrayList<Integer>> investigatedHashMap, HashMap<Integer,ArrayList<Integer>> arrayListHashMap){
        boolean returnBoolean = true;
        if(investigatedHashMap.size() >= arrayListHashMap.size()){
            returnBoolean = false;
        }else{
            for(int i = 1; i <= investigatedHashMap.size(); i++){
                if((investigatedHashMap.get(i).get(0) != arrayListHashMap.get(i).get(0)) || (investigatedHashMap.get(i).get(1) != arrayListHashMap.get(i).get(1))){
                    returnBoolean = false;
                    break;
                }
            }
        }
        return returnBoolean;
    }
//THIS METHOD TAKES THE BACKTRACKED HASHMAP AND TRIES TO FIND ALL THE BEATEN PATHS!!!
    private static ArrayList<ArrayList<Integer>> findingOldPaths(HashMap<Integer,ArrayList<Integer>> argumentHashMap){
        ArrayList<ArrayList<Integer>> returnMoves = new ArrayList<ArrayList<Integer>>();
        int x;
        int y;
        if(argumentHashMap.size() == 0){
            x = Integer.parseInt(Human.getHumanStartCoordinates().get(0));
            y = Integer.parseInt(Human.getHumanStartCoordinates().get(1));
        }else{
            x = argumentHashMap.get(argumentHashMap.size()).get(0);
            y = argumentHashMap.get(argumentHashMap.size()).get(1);
        }
        for(int i = 0; i < arrayOfAttemptHashMaps.size(); i++){
            boolean hashMapsAreTheSame = comparingHashMaps(argumentHashMap, arrayOfAttemptHashMaps.get(i));
            if(hashMapsAreTheSame == true){
                returnMoves.add(arrayOfAttemptHashMaps.get(i).get(argumentHashMap.size() + 1));
            }
        }
        return returnMoves;
    }
//THIS METHOD TAKES ALL THE POSSIBLE MOVES, EXTRACTS THE MOVES WE HAVE ALREADY DONE, AND RETURNS A LIST WITH WHATEVER IS LEFT!!!
    private static ArrayList<ArrayList<Integer>> returningNotDoneMoves(HashMap<Integer,ArrayList<Integer>> hashMapAfterBacktrack){
        ArrayList<ArrayList<Integer>> returnArrayList = new ArrayList<ArrayList<Integer>>();
        Human human = new Human();
        if(hashMapAfterBacktrack.size() > 0) {
            int x = hashMapAfterBacktrack.get(hashMapAfterBacktrack.size()).get(0);
            int y = hashMapAfterBacktrack.get(hashMapAfterBacktrack.size()).get(1);
            human.setHumanX(x);
            human.setHumanY(y);
        }
        ArrayList<ArrayList<Integer>> allPossibleMoves = human.humanMoves();
        ArrayList<ArrayList<Integer>> alreadyDoneMoves = findingOldPaths(hashMapAfterBacktrack);
        for (int i = 0; i < allPossibleMoves.size(); i++) {
            ArrayList<Integer> move = allPossibleMoves.get(i);
            boolean moveIsDone = false;
            for (int j = 0; j < alreadyDoneMoves.size(); j++) {
                if ((move.get(0) == alreadyDoneMoves.get(j).get(0)) && (move.get(1) == alreadyDoneMoves.get(j).get(1))) {
                    moveIsDone = true;
                }
            }
            if (moveIsDone == false) {
                returnArrayList.add(move);
            }
        }
        return returnArrayList;
    }
//THIS METHOD DOES WHAT THE FIRST ATTEMPT METHOD DOES, BUT WITH A FEW CHANGES!!!
    private static void escapeAttempt(HashMap<Integer,ArrayList<Integer>> hashMapAfterBacktrack,
                                      ArrayList<ArrayList<Integer>> notDoneMoves){
        //Create and set up the human and monster to their positions.
        Human human = new Human();
        Monster monster = new Monster();
        if(hashMapAfterBacktrack.size() > 0){
            human.setHumanX(hashMapAfterBacktrack.get(hashMapAfterBacktrack.size()).get(0));
            human.setHumanY(hashMapAfterBacktrack.get(hashMapAfterBacktrack.size()).get(1));
            monster.setMonsterX(hashMapAfterBacktrack.get(hashMapAfterBacktrack.size()).get(2));
            monster.setMonsterY(hashMapAfterBacktrack.get(hashMapAfterBacktrack.size()).get(3));
        }
        int moveCounter = hashMapAfterBacktrack.size() + 1;
        //Now we make the first move which is different to the next ones (if any).
        human.humanIsMoving(notDoneMoves);
        monster.monsterMoves(human);
        ArrayList<Integer> firstMove = new ArrayList<Integer>();
        firstMove.add(human.getHumanX());
        firstMove.add(human.getHumanY());
        firstMove.add(monster.getMonsterX());
        firstMove.add(monster.getMonsterY());
        hashMapAfterBacktrack.put(moveCounter, firstMove);
        moveCounter+=1;
        //Now we need to create a loop that keeps on going until the human has escaped or is eaten. If one
        //of the two is already true, we won't enter the loop at all.
        while (humanEscaped == false && humanIsEaten == false && moveCounter < movesUpperLimit){
            //JUST FOR VISUAL EFFECT WE SEE THE ATTEMPT COUNT GO UP!!!
            System.out.println(arrayOfAttemptHashMaps.size());
            //First one to move is the human.
            human.humanIsMoving();
            //and now the monster moves.
            monster.monsterMoves(human);
            //Now we add the human move to the HashMap.
            ArrayList<Integer> move = new ArrayList<Integer>();
            move.add(human.getHumanX());
            move.add(human.getHumanY());
            move.add(monster.getMonsterX());
            move.add(monster.getMonsterY());
            hashMapAfterBacktrack.put(moveCounter, move);
            moveCounter+=1;
        }
        //Once we have exited the loop, we need to reset the humanIsEaten boolean...
        humanIsEaten = false;
        //...let the user know if the attempt ended prematurely...
        if(moveCounter == movesUpperLimit && humanEscaped == false){
            Monster.getMonsterAndHumanMovesLog().add("This attempt took more moves than allowed, so it ended prematurely");
        }
        /////////////////////////////////////////////////////
        //THESE LINES OF CODE ARE HERE AS AN EXTRA SECURITY MEASURE, BECAUSE GOD FORBID WE GET TWO IDENTICAL HASHMAPS!!!
        for(int i = 0; i < arrayOfAttemptHashMaps.size();i++){
            boolean problem = true;
            if(hashMapAfterBacktrack.size() != arrayOfAttemptHashMaps.get(i).size()){
                problem = false;
            }else{
                for(int j =1; j <= hashMapAfterBacktrack.size(); j++){
                    if(hashMapAfterBacktrack.get(j).get(0) != arrayOfAttemptHashMaps.get(i).get(j).get(0) ||
                            hashMapAfterBacktrack.get(j).get(1) != arrayOfAttemptHashMaps.get(i).get(j).get(1)){
                        problem = false;
                        break;
                    }
                }
            }
            if(problem == true){
                System.out.println("WE HAVE DUPLICATE HASHMAPS HERE!!!");
                System.exit(1);
            }
        }
        //THESE LINES OF CODE ARE HERE AS AN EXTRA SECURITY MEASURE, BECAUSE GOD FORBID WE GET TWO IDENTICAL HASHMAPS!!!
        ////////////////////////////////////////////////////
        //...and we also need to add this attempt to the list.
        arrayOfAttemptHashMaps.add(hashMapAfterBacktrack);
    }
//THIS METHOD WILL PRINT ALL THE MOVES THAT HAVE ALREADY BEEN DONE, UP UNTIL THE POINT THE HASHMAP HAS BEEN BACKTRACKED!!!
    private static void recordingWhatHasAlreadyHappened(HashMap<Integer,ArrayList<Integer>> hashMapAfterBacktrack){
        if(hashMapAfterBacktrack.size() > 0){
            for(int i = 1; i <= hashMapAfterBacktrack.size(); i++){
               String hx = Integer.toString(hashMapAfterBacktrack.get(i).get(0));
               String hy = Integer.toString(hashMapAfterBacktrack.get(i).get(1));
                String mx = Integer.toString(hashMapAfterBacktrack.get(i).get(2));
                String my = Integer.toString(hashMapAfterBacktrack.get(i).get(3));
                String log = "Human has already moved to --> " + hx + "," + hy;
                Monster.getMonsterAndHumanMovesLog().add(log);
                log = "Monster has already moved to --> " + mx + "," + my;
                Monster.getMonsterAndHumanMovesLog().add(log);
            }
        }else{
            Monster.getMonsterAndHumanMovesLog().add("NO PREVIOUS MOVES HAVE BEEN MADE.");
        }
    }
//THIS METHOD CREATES THE BOARD.
    public static void createTheBoard(String filePath) throws FileNotFoundException {
        theBoard = BoardRoom.createBoardRoom(filePath);
    }


//THIS IS THE METHOD WHERE WE GATHER ALL OUR TOOLS AND USE THEM.
    public static void escapeProcess() {
        //...then we make our first attempt
        firstEscapeAttempt();
        int movesToBacktrack = 1;
        //Now we enter a loop that we won't get out of, until we reach a conclusion on the dungeon.
        while(humanEscaped == false && thereIsNoEscape == false){
            //First, we need to take a hashMap and backtrack it.
            //We need to see if there are hashMaps in the attempt list that are exactly the
            //same up to the point of our backtracked hashmap. If they are the same, we need to
            //extract the next move on their list, so that we don't make it now in this attempt.
            HashMap<Integer,ArrayList<Integer>> hashMapAfterBacktrack =
                    backtrackingTheHashMap(arrayOfAttemptHashMaps.get(hashMapSearchCount),movesToBacktrack);
            ArrayList<ArrayList<Integer>> notDoneMoves = returningNotDoneMoves(hashMapAfterBacktrack);
            if(notDoneMoves.size() == 0){
                if(hashMapAfterBacktrack.size() == 0){
                    movesToBacktrack = 1;
                    hashMapSearchCount+=1;
                    if(hashMapSearchCount >= arrayOfAttemptHashMaps.size()){
                        thereIsNoEscape = true;
                        Monster.getMonsterAndHumanMovesLog().add("THIS DUNGEON HAS NO SOLUTION!!!");
                    }
                }else{
                    movesToBacktrack+=1;
                }
            }
            else if(notDoneMoves.size() != 0){
                Monster.getMonsterAndHumanMovesLog().add("ATTEMPT NUMBER: "
                        + (arrayOfAttemptHashMaps.size() + 1) + " STARTS HERE:");
                recordingWhatHasAlreadyHappened(hashMapAfterBacktrack);
                escapeAttempt(hashMapAfterBacktrack,notDoneMoves);
                Monster.getMonsterAndHumanMovesLog().add("ATTEMPT NUMBER: "
                        + arrayOfAttemptHashMaps.size() + " ENDS.");
            }
        }
    }
//This method here is going to print EVERYTHING into text file.
    public static void printToTextFile(File userFriendlyFilePath){

        try{
            FileWriter fileWriter = new FileWriter(userFriendlyFilePath);
            PrintWriter printWriter = new PrintWriter(fileWriter);
            for(int i = 0; i < Monster.getMonsterAndHumanMovesLog().size(); i++){
                printWriter.println(Monster.getMonsterAndHumanMovesLog().get(i));
            }
            printWriter.close();
            fileWriter.close();
        }catch (IOException wrongPathGiven){
            System.out.println("Wrong filepath for user friendly text file.");
        }
    }

}//END OF CLASS!!!
