import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        //Create a scanner so that the user can give input.
        Scanner scanner = new Scanner(System.in);
        //These are the menus in which the user gives input. If the user messes up the input, the program won't end.
        boolean success = false;
        String userGivenFilePath = "Hello world";
        while(success == false){
            success = true;
            try{
                //Ask the user for filepath.
                System.out.print("Give me filepath for board design instructions: ");
                userGivenFilePath = scanner.nextLine();
                EscapeAttempt.createTheBoard(userGivenFilePath);
            }
            catch(Exception e){
                System.out.println("Wrong filepath given for board instructions location. Try again.");
                success = false;
            }
        }
        success = false;
        String userGivenFolderPath = "Hello world";
        while(success == false){
            success = true;
            try{
                //Ask user for filepath to save all the .txt files.
                System.out.print("Give me filepath for the location you want the created file to be at: ");
                userGivenFolderPath = scanner.nextLine();
                File testPathFile = new File(userGivenFolderPath + "\\test-path file.txt");
                FileWriter fileWriter = new FileWriter(testPathFile);
                PrintWriter printWriter = new PrintWriter(fileWriter);
                printWriter.println("Valid folder path given!");
                printWriter.close();
                fileWriter.close();
            }
            catch(Exception e){
                System.out.println("Wrong filepath given for the folder in which you want all the text files to be created at. Try again.");
                success = false;
            }
        }
        success = false;
        int userGivenUpperLimit = 0;
        while(success == false){
            success = true;
            try{
                //Ask user for moves limit.
                System.out.print("Give me the moves per attempt limit: ");
                userGivenUpperLimit = scanner.nextInt();
                EscapeAttempt.setMovesUpperLimit(userGivenUpperLimit);
            }
            catch(Exception e){
                System.out.println("Something about the input you gave is wrong. Try again.");
                success = false;
            }
            if(userGivenUpperLimit <= 0){
                System.out.println("Invalid number given. Try again.");
                success = false;
            }
            else{
                EscapeAttempt.setMovesUpperLimit(userGivenUpperLimit);
            }
        }
        EscapeAttempt.escapeProcess();
        EscapeAttempt.printToTextFile(new File(userGivenFolderPath + "\\attempts-log file.txt"));
        if(EscapeAttempt.getThereIsNoEscape() == true){
            System.out.println("There is no escape from this dungeon. Attempts made: " + EscapeAttempt.getArrayOfAttemptHashMaps().size());
        }else{
            System.out.println("The human managed to escape after " + EscapeAttempt.getArrayOfAttemptHashMaps().size() + " attempts.");
        }
    }
}

