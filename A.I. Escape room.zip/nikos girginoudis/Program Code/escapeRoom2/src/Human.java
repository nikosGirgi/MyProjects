import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Human {
    private int humanX;
    private int humanY;
    private static ArrayList<String> humanStartCoordinates = new ArrayList<String>();
    public Human(){
        //Even though we don't give human its variables in the
        //arguments, it still gets them from the arrayList.
        this.humanX = Integer.parseInt(humanStartCoordinates.get(0));
        this.humanY = Integer.parseInt(humanStartCoordinates.get(1));
    }
    //This method figures out what our potential moves are,
    //and then discards the ones that can't be executed
    //because of walls, holes and board limits.
    public ArrayList<ArrayList<Integer>> humanMoves(){
        //This is an arrayList to store all the possible moves.
        ArrayList<ArrayList<Integer>> possibleMoves = new ArrayList<ArrayList<Integer>>();
        //And here is an arrayList to store all the valid moves.
        ArrayList<ArrayList<Integer>> validMoves = new ArrayList<ArrayList<Integer>>();
        //Now we need to figure out the coordinates of all the
        //neighboring tiles and decide if they are valid tiles.
        int x;
        int y;
        //Here we figure out the moves on the x-axis.
        //Left.
        y = this.humanY;
        x = this.humanX - 1;
        if(x > 0){
           ArrayList<Integer> validBoardersMove = new ArrayList<Integer>();
            validBoardersMove.add(x);
            validBoardersMove.add(y);
            possibleMoves.add(validBoardersMove);
        }
        //Right.
        y = this.humanY;
        x = this.humanX + 1;
        if(x <= BoardRoom.getXAxis()) {
            ArrayList<Integer> validBoardersMove = new ArrayList<Integer>();
            validBoardersMove.add(x);
            validBoardersMove.add(y);
            possibleMoves.add(validBoardersMove);
        }
        //And here we figure out the moves on the y-axis.
        //Down.
        y = this.humanY - 1;
        x = this.humanX;
        if(y > 0){
            ArrayList<Integer> validBoardersMove = new ArrayList<Integer>();
            validBoardersMove.add(x);
            validBoardersMove.add(y);
            possibleMoves.add(validBoardersMove);
        }
        //Up.
        y = this.humanY + 1;
        x = this.humanX;
        if(y <= BoardRoom.getYAxis()){
            ArrayList<Integer> validBoardersMove = new ArrayList<Integer>();
            validBoardersMove.add(x);
            validBoardersMove.add(y);
            possibleMoves.add(validBoardersMove);
        }
        //Now we are going to clear out the invalid moves due
        //to terrain. Those that are valid are added to the
        //valid arrayList.
        for(int i = 0; i < possibleMoves.size(); i++){
            //We are using the terrain method here.
            if(Terrain.humanMoveIsFreeOfTerrain(this.humanX, this.humanY,
                    possibleMoves.get(i).get(0), possibleMoves.get(i).get(1))){
                validMoves.add(possibleMoves.get(i));
            }
        }
        return validMoves;
    }
    //This method will be the one we use when the human moves, after all
    //the invalid moves are taken out. It is basically a pair of setters.
    public void humanIsMoving(){
        Random rand = new Random();
        int rand_int1 = rand.nextInt(this.humanMoves().size());
        ArrayList<ArrayList<Integer>> moves = this.humanMoves();
        this.humanX = moves.get(rand_int1).get(0);
        this.humanY = moves.get(rand_int1).get(1);
    }
    //This method does the same, only now we add an arraylist with the moves
    //that have already been made before and are therefore invalid.

    public void humanIsMoving(ArrayList<ArrayList<Integer>> notDoneMoves){
        //ArrayList<ArrayList<Integer>> allTheMoves = this.humanMoves();
        //ArrayList<ArrayList<Integer>> actualMoves = gettingRidOfRepeatedMoves(allTheMoves, notDoneMoves);
        Random rand = new Random();
        int rand_int1 = rand.nextInt(notDoneMoves.size());
        this.humanX = notDoneMoves.get(rand_int1).get(0);
        this.humanY = notDoneMoves.get(rand_int1).get(1);
    }
    //This method checks if the human is on the exit.
    public boolean humanIsOnExit(){
        boolean check = false;
        if(this.getHumanX() == EscapeAttempt.getExitX() && this.getHumanY() == EscapeAttempt.getExitY()){
            check = true;
        }
        return check;
    }
//BEGINNING OF SETTERS AND GETTERS!!!
    public int getHumanX() {
        return humanX;
    }

    public void setHumanX(int humanX) {
        this.humanX = humanX;
    }

    public int getHumanY() {
        return humanY;
    }

    public void setHumanY(int humanY) {
        this.humanY = humanY;
    }

    public static List<String> getHumanStartCoordinates() {
        return humanStartCoordinates;
    }

    public static void setHumanStartCoordinates(ArrayList<String> humanStartCoordinates) {
        Human.humanStartCoordinates = humanStartCoordinates;
    }
//ENDING OF SETTERS AND GETTERS!!!
}
